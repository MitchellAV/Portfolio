<?php
  $hn = 'biogasproject.000webhostapp.com';
  $un = 'id9511915_mitchell';
  $pw = 'skater872';
  $db = 'id9511915_biomassproject';
 ?>
