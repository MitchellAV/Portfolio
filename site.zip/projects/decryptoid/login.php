<?php
  $hn = 'localhost';
  $un = 'mitchell';
  $pw = 'mypasswd';
  $db = 'homework';
 ?>
